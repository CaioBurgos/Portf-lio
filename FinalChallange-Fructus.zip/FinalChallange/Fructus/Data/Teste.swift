//
//  Teste.swift
//  Fructus
//
//  Created by Caio Burgos dos Santos on 05/10/23.
//

import SwiftUI

struct Teste: View {
    var body: some View {
        Text("Hello, World!")
    }
}

#Preview {
    Teste()
}
