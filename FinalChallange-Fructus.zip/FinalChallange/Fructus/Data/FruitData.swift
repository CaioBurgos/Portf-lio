//
//  Teste.swift
//  Fructus
//
//  Created by Caio Burgos dos Santos on 05/10/23.
//

import SwiftUI

// MARK: - FRUITS DATA

let fruitsData: [Fruit] = [
  Fruit(
      title: "Mirtilos",
      headline: "Os mirtilos são frutas doces, nutritivas e muito populares em todo o mundo.",
      image: "mirtilos",
      gradientColors: [Color("ColorBlueberryLight"), Color("ColorBlueberryDark")],
      description: """
        Os mirtilos são plantas com flores perenes com frutos azuis ou roxos. Eles são classificados na seção Cyanococcus do gênero Vaccinium. Vaccinium também inclui cranberries, mirtilos, mirtilos e mirtilos da Madeira.

                Mirtilos comerciais - tanto silvestres (lowbush) quanto cultivados (highbush) - são todos nativos da América do Norte. As variedades highbush foram introduzidas na Europa durante a década de 1930.

                Os mirtilos são geralmente arbustos prostrados que podem variar em tamanho de 10 centímetros (3,9 pol.) A 4 metros (13 pés) de altura. Na produção comercial de mirtilos, as espécies com frutos pequenos do tamanho de ervilhas que crescem em arbustos baixos são conhecidas como "mirtilos lowbush" (sinônimo de "selvagem"), enquanto as espécies com frutos maiores que crescem em arbustos cultivados mais altos são conhecidas como "mirtilos highbush".

                O Canadá é o principal produtor de mirtilos de arbusto baixo, enquanto os Estados Unidos produzem cerca de 40% da oferta mundial de mirtilos de arbusto alto.

                USOS

                Os mirtilos são vendidos frescos ou processados ​​​​como frutas congeladas individualmente (IQF), purê, suco ou frutas secas ou em infusão. Estes podem então ser usados ​​em uma variedade de bens de consumo, como geleias, geléias, tortas de mirtilo, muffins, salgadinhos ou como aditivo para cereais matinais.

                A geléia de mirtilo é feita de mirtilo, açúcar, água e pectina de frutas. O molho de mirtilo é um molho doce preparado com mirtilos como ingrediente principal.

                O vinho de mirtilo é feito a partir da polpa e da casca da fruta, que é fermentada e depois amadurecida; geralmente a variedade lowbush é usada.

                NUTRIENTES

                Os mirtilos consistem em 14% de carboidratos, 0,7% de proteína, 0,3% de gordura e 84% de água (mesa). Contêm apenas quantidades insignificantes de micronutrientes, com níveis moderados (em relação aos respectivos Valores Diários) (DV) do mineral dietético essencial manganês, vitamina C, vitamina K e fibra alimentar (tabela).

                Geralmente, o conteúdo de nutrientes dos mirtilos é uma porcentagem baixa do DV (tabela). Uma porção fornece um valor calórico relativamente baixo de 57 kcal com uma carga glicêmica de 6.
        """,
      nutrition: ["240 kJ (57 kcal)","9.96 g","0.33 g","0.74 g","A, B1, B2, B3, B5, B6, B9, C, E, K","Calcium, Iron, Magnasium, Manganese, Phosphorus, Sodium, Zinc"]
    ),
    Fruit(
      title: "Morango",
      headline: "Muito apreciado pelo seu aroma característico, cor vermelha, textura suculenta e doçura.",
      image: "morango",
      gradientColors: [Color("ColorStrawberryLight"), Color("ColorStrawberryDark")],
      description: """
        O morango de jardim (ou simplesmente morango; Fragaria × ananassa) é uma espécie híbrida amplamente cultivada do gênero Fragaria, conhecida coletivamente como morangos, que são cultivados em todo o mundo por seus frutos. A fruta é muito apreciada pelo seu aroma característico, cor vermelha brilhante, textura suculenta e doçura. É consumido em grandes quantidades, seja in natura ou em alimentos preparados como geléias, sucos, tortas, sorvetes, milkshakes e chocolates. Aromas e aromas artificiais de morango também são amplamente utilizados em produtos como doces, sabonetes, brilho labial, perfumes e muitos outros.

        O morango não é, do ponto de vista botânico, uma baga. Tecnicamente, é um fruto acessório agregado, o que significa que a parte carnuda não deriva dos ovários da planta, mas do receptáculo que contém os ovários.[4] Cada "semente" aparente (aquênio) na parte externa do fruto é na verdade um dos ovários da flor, com uma semente dentro dele.

                CULINÁRIA

                Além de serem consumidos frescos, os morangos podem ser congelados ou transformados em compotas ou conservas,[45] bem como secos e utilizados em alimentos preparados, como barras de cereais. Morangos e aromas de morango são uma adição popular aos produtos lácteos, como leite de morango, sorvete de morango, milkshakes/smoothies de morango e iogurtes de morango.
        
        No Reino Unido, "morangos com creme" é uma sobremesa popular consumida no torneio de tênis de Wimbledon.[5] Morangos com creme também são um lanche básico no México, geralmente disponíveis em sorveterias. Na Suécia, os morangos são uma sobremesa tradicional servida no Dia de São João, também conhecido como Véspera do Solstício de Verão. Dependendo da região, torta de morango, torta de morango e ruibarbo ou torta de morango também são comuns. Na Grécia, os morangos podem ser polvilhados com açúcar e depois mergulhados em Metaxa, um conhaque, e servidos como sobremesa. Na Itália, os morangos são usados ​​em diversas sobremesas e como aromatizante comum para gelato (gelato alla fragola).

                Suonenjoki, na Savônia do Norte, na Finlândia, é uma pequena cidade famosa por seus morangos, por isso também é conhecida como "a Cidade dos Morangos" ou "a Capital dos Morangos". Muitos estrangeiros, principalmente da Ucrânia e da Rússia, vêm para Suonenjoki no verão para trabalhar nas fazendas de morangos. Isso faz de Suonenjoki a cidade mais internacional da Finlândia no verão. Há uma festa em Suonenjoki em julho chamada Mansikkakarnevaalit, "Carnaval do Morango".

        NUTRIÇÃO

                Uma porção (100 g; ver tabela) de morango contém aproximadamente 33 quilocalorias, é uma excelente fonte de vitamina C, uma boa fonte de manganês e fornece diversas outras vitaminas e minerais dietéticos em menores quantidades.

                Os morangos contêm uma quantidade modesta de ácidos graxos insaturados essenciais no óleo de aquênio (semente).
        """,
      nutrition: ["136 kJ (33 kcal)","4,89 g","0,3 g","0,67 g","B1, B2, B3, B5, B6, B9, Colina, C, E, K","Cálcio, Ferro, Magnásio, Manganês, Fósforo, Potássio, Sódio, Zinco"]
    ),
    Fruit(
      title: "Limão",
      headline: "Não há dúvida de que limões são deliciosos, mas adicioná-los à água deixa você mais saudável?",
      image: "limão",
      gradientColors: [Color("ColorLemonLight"), Color("ColorLemonDark")],
      description: """
        O limão, Citrus limon, é uma espécie de pequena árvore perene da família das plantas com flores Rutaceae, nativa do sul da Ásia, principalmente do nordeste da Índia. Seus frutos são redondos.
        
        O fruto amarelo elipsoidal da árvore é utilizado para fins culinários e não culinários em todo o mundo, principalmente pelo seu suco, que tem uso culinário e de limpeza. A polpa e a casca também são utilizadas na culinária e panificação. O suco do limão contém cerca de 5% a 6% de ácido cítrico, com pH em torno de 2,2, o que lhe confere um sabor amargo. O sabor amargo característico do suco de limão o torna um ingrediente-chave em bebidas e alimentos como limonada e torta de merengue de limão.

        NUTRIÇÃO

                O limão é uma fonte rica em vitamina C, fornecendo 64% do valor diário numa quantidade de referência de 100 g (tabela). Outros nutrientes essenciais são de baixo teor.

                Limões contêm numerosos fitoquímicos, incluindo polifenóis, terpenos e taninos.[14] O suco de limão contém um pouco mais de ácido cítrico do que o suco de limão (cerca de 47 g/l), quase o dobro do ácido cítrico do suco de toranja e cerca de cinco vezes a quantidade de ácido cítrico encontrada no suco de laranja.

                CULINÁRIA
                
                Suco, casca e casca de limão são usados ​​em uma ampla variedade de alimentos e bebidas. O limão inteiro é usado para fazer marmelada, coalhada de limão e licor de limão. Fatias e cascas de limão são usadas como guarnição de alimentos e bebidas. As raspas de limão, a casca ralada da fruta, são usadas para dar sabor a assados, pudins, arroz e outros pratos.
        SUCO

                O suco de limão é usado para fazer limonadas, refrigerantes e coquetéis. É utilizado em marinadas de peixes, onde seu ácido neutraliza as aminas dos peixes, convertendo-as em sais de amônio não voláteis. Na carne, o ácido hidrolisa parcialmente as fibras duras de colágeno, amaciando-as.[18] No Reino Unido, o suco de limão é frequentemente adicionado às panquecas, especialmente na terça-feira gorda.

                O suco de limão também é usado como conservante de curto prazo em certos alimentos que tendem a oxidar e ficar marrons após serem fatiados (escurecimento enzimático), como maçãs, bananas e abacates, onde seu ácido desnatura as enzimas.

                CASCA

                Em Marrocos, os limões são conservados em potes ou barris de sal. O sal penetra na casca e na casca, amolecendo-as e curando-as para que durem quase indefinidamente.[19] O limão em conserva é utilizado nos mais diversos pratos. Limões em conserva também podem ser encontrados em pratos sicilianos, italianos, gregos e franceses.

                A casca pode ser utilizada na fabricação de pectina, polissacarídeo utilizado como agente gelificante e estabilizante em alimentos e outros produtos.[20]

                ÓLEO

                O óleo de limão é extraído de células da pele que contêm óleo. Uma máquina quebra as células e usa um spray de água para remover o óleo. A mistura óleo/água é então filtrada e separada por centrifugação.[21]
        FOLHAS

                As folhas do limoeiro são utilizadas para fazer chá e preparar carnes cozidas e frutos do mar.
        """,
      nutrition: ["121 kJ (29 kcal)","2,5 g","0,3 g","1,1 g","B1, B2, B3, B5, B6, B9, C, Colina","Cálcio, Ferro, Magnésio, Manganês, Fósforo, Potássio, Zinco"]
    ),
    Fruit(
      title: "Ameixa",
      headline: "A ameixa é uma fruta muito nutritiva. Excelente fonte de vitaminas, minerais, fibras e antioxidantes.",
      image: "ameixa",
      gradientColors: [Color("ColorPlumLight"), Color("ColorPlumDark")],
      description: """
        A ameixa é uma fruta do subgênero Prunus do gênero Prunus. O subgênero se distingue de outros subgêneros (pêssegos, cerejas, cerejas de pássaros, etc.) pelos brotos com botão terminal e botões laterais solitários (não agrupados), pelas flores em grupos de um a cinco juntas em hastes curtas, e pelos frutos com uma ranhura descendo por um lado e uma pedra lisa (ou poço).

                As ameixas maduras podem ter uma camada cerosa branca empoeirada que lhes confere uma aparência glauca. Este é um revestimento de cera epicuticular conhecido como "flor de cera". Os frutos secos da ameixa são chamados de "ameixas secas" ou ameixas secas, embora, em muitos países, as ameixas secas sejam um tipo distinto de ameixa seca com aparência enrugada (Li hing mui, por exemplo).

                DESCRIÇÃO

                As ameixas são um grupo diversificado de espécies. As ameixeiras comercialmente importantes são de tamanho médio, geralmente podadas até 5–6 metros de altura. A árvore é de robustez média. Sem poda, as árvores podem atingir 12 metros de altura e se espalhar por 10 metros. Florescem em meses diferentes em diferentes partes do mundo; por exemplo, por volta de janeiro em Taiwan e no início de abril no Reino Unido.

                Os frutos são geralmente de tamanho médio, entre 2 e 7 centímetros de diâmetro, globosos a ovais. A polpa é firme e suculenta. A casca da fruta é lisa, com superfície cerosa natural que adere à polpa. A ameixa é uma drupa, o que significa que seu fruto carnudo envolve uma única semente dura.

        CULTIVO

                Quando floresce no início da primavera, a ameixeira estará coberta de flores e, em um ano bom, aproximadamente 50% das flores serão polinizadas e se transformarão em ameixas. A floração começa após 80 graus-dia de crescimento.

                Se o tempo estiver muito seco, as ameixas não se desenvolverão além de um certo estágio, mas cairão da árvore ainda com pequenos botões verdes, e se estiver excepcionalmente úmido ou se as ameixas não forem colhidas assim que estiverem maduras, a fruta pode desenvolver uma doença fúngica chamada podridão parda. A podridão parda não é tóxica e algumas áreas afetadas podem ser cortadas da fruta, mas, a menos que a podridão seja detectada imediatamente, a fruta não será mais comestível. A ameixa é usada como planta alimentar pelas larvas de alguns lepidópteros, incluindo a mariposa de novembro, a beleza do salgueiro e a mariposa de capa curta.

                O sabor da ameixa varia do doce ao ácido; a própria pele pode ser particularmente ácida. É suculento e pode ser consumido fresco ou utilizado na confecção de compotas ou outras receitas. O suco de ameixa pode ser fermentado em vinho de ameixa. No centro da Inglaterra, uma bebida alcoólica semelhante à cidra, conhecida como plum jerkum, é feita de ameixas. Ameixas secas e salgadas são utilizadas como lanche, às vezes conhecidas como saladito ou salao.

                Vários sabores de ameixa seca estão disponíveis em mercearias chinesas e lojas especializadas em todo o mundo. Eles tendem a ser muito mais secos do que a ameixa padrão. Creme, ginseng, picante e salgado estão entre as variedades comuns. O alcaçuz é geralmente usado para intensificar o sabor dessas ameixas e para fazer bebidas salgadas de ameixa e coberturas para gelo picado ou baobing. Ameixas em conserva são outro tipo de conserva disponível na Ásia e em lojas especializadas internacionais.

                A variedade japonesa, chamada umeboshi, é frequentemente usada para bolinhos de arroz, chamados onigiri ou omusubi. O ume, do qual é feito o umeboshi, está mais relacionado, porém, ao damasco do que à ameixa. Nos Bálcãs, a ameixa é convertida em uma bebida alcoólica chamada slivovitz (conhaque de ameixa) (sérvio: šljivovica).

                Um grande número de ameixas, da variedade Damson, também são cultivadas na Hungria, onde são chamadas de szilva e são usadas para fazer lekvar (uma geléia de pasta de ameixa), palinka (conhaque de frutas tradicional), bolinhos de ameixa e outros alimentos. Na Roménia, 80% da produção de ameixa é utilizada para criar uma aguardente semelhante, chamada țuică.
        """,
      nutrition: ["192 kJ (46 kcal)","9,92 g","0,28 g","0,7 g","A, B1, B2, B3, B5, B6, B9, C, E, K","Cálcio, Ferro, Magnásio, Manganês, Fósforo, Potássio, Sódio, Zinco"]
    ),
    Fruit(
      title: "Limão Lima",
      headline: "nossas frutas cítricas redondas e verdes brilhantes. O limão é rico em vitamina C, antioxidantes e outros nutrientes.",
      image: "lima",
      gradientColors: [Color("ColorLimeLight"), Color("ColorLimeDark")],
      description: """
      Um limão (do francês lime, do árabe līma, do persa līmū, "limão")[1] é uma fruta cítrica, que é tipicamente redonda, de cor verde, com 3–6 centímetros (1,2–2,4 pol.) de diâmetro e contém vesículas de suco ácido.

            Existem várias espécies de árvores cítricas cujos frutos são chamados de limas, incluindo a lima-chave (Citrus aurantiifolia), a lima persa, a lima kaffir e a lima do deserto. O limão é uma fonte rica em vitamina C, é azedo e costuma ser usado para acentuar os sabores de alimentos e bebidas. Eles são cultivados o ano todo.[3] As plantas com frutos chamados “limões” têm origens genéticas diversas; limas não formam um grupo monofilético.

            CULTIVO

            O limão tem maior teor de açúcares e ácidos do que o limão.[2] O suco de limão pode ser espremido de limão fresco ou comprado em garrafas em variedades sem açúcar e adoçadas. O suco de limão é usado para fazer limonada e como ingrediente (normalmente como mistura azeda) em muitos coquetéis.

            Picles de limão são parte integrante da culinária indiana. A culinária do sul da Índia é fortemente baseada em limão; ter picles de limão ou picles de limão é considerado essencial para Onam Sadhya.

            Na culinária, o limão é valorizado tanto pela acidez do suco quanto pelo aroma floral das raspas. É um ingrediente comum em autênticos pratos mexicanos, vietnamitas e tailandeses. A sopa de limão é um prato tradicional do estado mexicano de Yucatán. Também é usado por suas propriedades de decapagem em ceviche. Algumas receitas de guacamole pedem suco de limão.

            O uso de limão seco (chamado limão preto ou loomi) como condimento é típico da culinária persa e iraquiana, bem como no baharat ao estilo do Golfo Pérsico (uma mistura de especiarias também chamada de kabsa ou kebsa).

      O limão é um ingrediente de muitas cozinhas da Índia, e muitas variedades de picles são feitas, por ex. picles de limão adoçado, picles salgados e chutney de limão.

            O limão dá o sabor característico à sobremesa americana conhecida como torta de limão. Na Austrália, a cal do deserto é usada para fazer marmelada.

            O limão é ingrediente de vários coquetéis highball, muitas vezes à base de gin, como o gin tônico, o gimlet e o Rickey. O suco de limão espremido na hora também é considerado um ingrediente chave nas margaritas, embora às vezes o suco de limão seja substituído. Também está intimamente associado a muitos coquetéis de rum, como o Daiquiri, e bebidas tropicais - especialmente na cultura Tiki.

            Extratos e óleos essenciais de limão são frequentemente usados ​​em perfumes, produtos de limpeza e aromaterapia.
      """,
      nutrition: ["126 kJ (30 kcal)","1,7 g","0,2 g","0,7 g","B1, B2, B3, B5, B6, B9, C","Cálcio, Ferro, Magnésio, Fósforo, Potássio, Sódio"]
    ),
    Fruit(
      title: "Romã",
      headline: "frutas doces em forma de sino, apreciadas desde a antiguidade. Eles podem ser consumidos crocantes ou macios.",
      image: "romã",
      gradientColors: [Color("ColorPomegranateLight"), Color("ColorPomegranateDark")],
      description: """
        A romã (Punica granatum) é um arbusto decíduo frutífero da família Lythraceae, subfamília Punicoideae, que cresce entre 5 e 10 m (16 e 33 pés) de altura.

                A romã é originária da região que se estende do Irão ao norte da Índia e é cultivada desde a antiguidade em toda a região do Mediterrâneo. Foi introduzido na América espanhola no final do século 16 e na Califórnia pelos colonos espanhóis em 1769.

                A fruta é tipicamente sazonal no Hemisfério Norte, de setembro a fevereiro, e no Hemisfério Sul, de março a maio. Como sarcotestas ou suco intactos, as romãs são usadas na panificação, culinária, misturas de sucos, guarnições de refeições, smoothies e bebidas alcoólicas, como coquetéis e vinho.

                DESCRIÇÃO

                De cor vermelho-púrpura, a casca do fruto da romã tem duas partes: um pericarpo externo duro e um mesocarpo interno esponjoso (“albedo” branco), que compreende a parede interna do fruto onde as sementes se fixam. As membranas do mesocarpo são organizadas como câmaras assimétricas que contêm sementes dentro de sarcotestas, que ficam embutidas sem fixação no mesocarpo. Contendo suco, a sarcotesta é formada como uma fina membrana derivada das células epidérmicas das sementes. O número de sementes de uma romã pode variar de 200 a cerca de 1.400.

                Botanicamente, o fruto comestível é uma baga com sementes e polpa produzida a partir do ovário de uma única flor. O fruto tem tamanho intermediário entre um limão e uma toranja, 5–12 cm (2–5 pol.) De diâmetro, formato arredondado e casca espessa e avermelhada.

                CULTIVO

        A romã granatum é cultivada para sua produção de frutas e como árvores e arbustos ornamentais em parques e jardins. Espécimes maduros podem desenvolver vários troncos esculturais de casca torcida e uma forma geral distinta. As romãs são tolerantes à seca e podem ser cultivadas em áreas secas com clima mediterrâneo com chuvas de inverno ou em climas com chuvas de verão. Em áreas mais úmidas, eles podem estar sujeitos à deterioração das raízes devido a doenças fúngicas. Eles podem ser tolerantes a geadas moderadas, até cerca de -12 °C (10 °F).

                As pragas de insetos da romã podem incluir a borboleta romã Virachola isocrates e o percevejo Leptoglossus zonatus, e moscas-das-frutas e formigas são atraídas por frutas maduras não colhidas. A romã cresce facilmente a partir da semente, mas é comumente propagada em estacas de madeira dura de 25 a 50 cm (10 a 20 pol.) para evitar a variação genética das mudas. A alporquia também é uma opção para propagação, mas a enxertia falha.
        """,
      nutrition: ["346 kJ (83 kcal)","13,67 g","1,17 g","1,67 g","B1, B2, B3, B5, B6, B9, C, E, K","Cálcio, Ferro, Magnésio, Manganês, Fósforo, Potássio, Sódio, Zinco"]
    ),
    Fruit(
      title: "Pêra",
      headline: "Frutos doces em forma de sino, apreciados desde a antiguidade. Eles podem ser consumidos crocantes ou macios.",
      image: "pêra",
      gradientColors: [Color("ColorPearLight"), Color("ColorPearDark")],
      description: """
        A Pêra (/ˈpɛər/) árvore e arbusto são uma espécie do gênero Pyrus /ˈpaɪrəs/, da família Rosaceae, que produz o fruto pomáceo de mesmo nome. Várias espécies de peras são valorizadas pelos seus frutos e sucos comestíveis, enquanto outras são cultivadas como árvores.

                A árvore é de tamanho médio e nativa das regiões costeiras e moderadamente temperadas da Europa, norte da África e Ásia. A madeira de pêra é um dos materiais preferidos na fabricação de instrumentos de sopro e móveis de alta qualidade.

                Cerca de 3.000 variedades conhecidas de peras são cultivadas em todo o mundo. A fruta é consumida in natura, enlatada, na forma de suco e desidratada.

                DESCRIÇÃO

                A pêra é nativa das regiões costeiras e moderadamente temperadas do Velho Mundo, da Europa Ocidental e do norte da África, a leste, através da Ásia. É uma árvore de tamanho médio, atingindo 10–17 metros (33–56 pés) de altura, geralmente com uma copa alta e estreita; algumas espécies são arbustivas.

                As folhas são dispostas alternadamente, simples, com 2–12 centímetros (1–4 1⁄2 pol.) De comprimento, verdes brilhantes em algumas espécies, densamente prateadas e peludas em outras; o formato da folha varia de oval largo a lanceolado estreito. A maioria das peras são caducas, mas uma ou duas espécies no sudeste da Ásia são perenes.
                
                A maioria é resistente ao frio, suportando temperaturas tão baixas quanto -25 a -40 °C (-13 a -40 °F) no inverno, exceto para as espécies perenes, que só toleram temperaturas abaixo de cerca de -15 °C (5 °C). F).

                CULTIVO

                De acordo com o Pear Bureau Northwest, cerca de 3.000 variedades conhecidas de peras são cultivadas em todo o mundo. A pêra é normalmente propagada enxertando uma variedade selecionada em um porta-enxerto, que pode ser de pêra ou marmelo. Os porta-enxertos de marmelo produzem árvores menores, o que muitas vezes é desejável em pomares comerciais ou jardins domésticos.

                Para novas variedades, as flores podem ser cruzadas para preservar ou combinar características desejáveis. O fruto da pêra é produzido sobre esporas, que aparecem nos brotos com mais de um ano.

                Três espécies representam a grande maioria da produção de frutos comestíveis, a pêra europeia Pyrus communis subsp. communis cultivada principalmente na Europa e na América do Norte, a pera branca chinesa (bai li) Pyrus ×bretschneideri e a pera Nashi Pyrus pyrifolia (também conhecida como pera asiática ou pera maçã), ambas cultivadas principalmente no leste da Ásia. Existem milhares de cultivares dessas três espécies.

                Uma espécie cultivada no oeste da China, P. sinkiangensis, e P. pashia, cultivada no sul da China e no sul da Ásia, também são produzidas em menor grau.

        Outras espécies são utilizadas como porta-enxertos para peras europeias e asiáticas e como árvores ornamentais. A madeira de pêra tem granulação fechada e, pelo menos no passado, foi usada como madeira especializada para móveis finos e na fabricação de blocos para xilogravuras. A pêra da Manchúria ou Ussuriana, Pyrus ussuriensis (que produz frutos desagradáveis) foi cruzada com Pyrus communis para criar cultivares de pêra mais resistentes.

                A pera Bradford (Pyrus calleryana 'Bradford'), em particular, tornou-se difundida na América do Norte e é usada apenas como árvore ornamental, bem como porta-enxerto resistente à ferrugem para pomares de frutas de Pyrus communis. A pêra com folhas de salgueiro (Pyrus salicifolia) é cultivada por suas folhas atraentes, delgadas e densamente prateadas.
        """,
      nutrition: ["239 kJ (57 kcal)","9,75 g","0,14 g","0,36 g","B1, B2, B3, B5, B6, B9, C, E, K","Cálcio, Ferro, Magnésio, Manganês, Fósforo, Potássio, Sódio, Zinco"]
    ),
    Fruit(
      title: "Groselha",
      headline: "frutas doces em forma de sino, apreciadas desde a antiguidade. Eles podem ser consumidos crocantes ou macios.",
      image: "groselha",
      gradientColors: [Color("ColorGooseberryLight"), Color("ColorGooseberryDark")],
      description: """
        A groselha (/ˈɡuːsbɛri/ ou /ˈɡuːzbɛri/ (americana e do norte da Grã-Bretanha) ou /ˈɡʊzbəri/ (sul da Grã-Bretanha)), com nomes científicos Ribes uva-crispa (e sin. Ribes grossularia), é uma espécie de Ribes (que também inclui as groselhas).

                É nativo da Europa, do Cáucaso e do norte da África. A espécie também é moderadamente naturalizada em locais dispersos na América do Norte. Os arbustos de groselha produzem frutos comestíveis e são cultivados tanto comercialmente quanto domesticamente. Sua distribuição nativa não é clara, pois pode ter escapado do cultivo e se naturalizado. Por exemplo, na Grã-Bretanha, algumas fontes consideram-no um nativo,[4] outras uma introdução.

                Embora geralmente colocado como um subgênero dentro de Ribes, alguns taxonomistas tratam Grossularia como um gênero separado, embora híbridos entre groselha e groselha preta (por exemplo, a jostaberry) sejam possíveis. O subgênero Grossularia difere um pouco das groselhas, principalmente em seus caules espinhosos e porque suas flores crescem uma a três juntas em caules curtos, não em racemos. É uma das várias espécies semelhantes do subgênero Grossularia; para as outras espécies relacionadas (por exemplo, groselha norte-americana Ribes hirtellum), consulte a página do gênero Ribes.

                CULTIVO

                Um método de propagação de groselhas é por meio de estacas, em vez de cultivar a partir de sementes; as mudas plantadas no outono criarão raízes rapidamente e poderão começar a dar frutos dentro de alguns anos. Aqueles que crescem a partir de sementes produzirão rapidamente arbustos saudáveis ​​e de alto rendimento. A poda deve ser realizada para permitir a entrada de luz e dar ao novo crescimento dos ramos do próximo ano uma oportunidade de crescer. Os frutos são produzidos nas esporas laterais e nos brotos do ano anterior.[13] O objetivo principal é deixar entrar a luz e um objetivo subsidiário é permitir a colheita sem arranhões excessivos nas lombadas.
        
        A compostagem pesada de nitrogênio deve ser evitada, pois muito nitrogênio produzirá um crescimento extensivo e enfraquecerá o arbusto. Isso tornará o arbusto suscetível ao mofo. A fruta deve ser colhida melhor quando grande para atingir a doçura máxima. Os supermercados tendem a ter os seus colhidos cedo e antes de estarem maduros e doces para proporcionar uma longa vida útil. Os ramos muito carregados devem ser cortados juntamente com os frutos silvestres, o que beneficia realmente as colheitas futuras, pois permite que a luz alcance o novo crescimento.

                CULINÁRIA

                As groselhas são comestíveis e podem ser consumidas como estão ou usadas como ingrediente em sobremesas, como tortas, tolos e migalhas. As primeiras colheitas são geralmente ácidas e mais apropriadas para uso culinário. Eles também são usados ​​para dar sabor a bebidas como refrigerantes, águas aromatizadas ou leite, e podem ser transformados em vinhos de frutas e chás. As groselhas podem ser conservadas na forma de geléias, frutas secas ou como ingrediente primário ou secundário em decapagem, ou armazenadas em calda de açúcar.
        """,
      nutrition: ["184 kJ (44 kcal)","6,15","0,58 g","0,88 g","A, B1, B2, B3, B5, B6, B9, C, E","Cálcio, Ferro, Magnésio, Manganês , Fósforo, Potássio, Sódio, Zinco"]
    ),
    Fruit(
      title: "Manga",
      headline: "frutas doces em forma de sino, apreciadas desde a antiguidade. Eles podem ser consumidos crocantes ou macios.",
      image: "manga",
      gradientColors: [Color("ColorMangoLight"), Color("ColorMangoDark")],
      description: """
        A manga é uma suculenta fruta de caroço (drupa) produzida a partir de inúmeras espécies de árvores tropicais pertencentes ao gênero de plantas com flores Mangifera, cultivadas principalmente por seus frutos comestíveis. A maioria dessas espécies é encontrada na natureza como mangas silvestres. O gênero pertence à família do caju Anacardiaceae. As mangas são nativas do Sul da Ásia, de onde a "manga comum" ou "manga indiana", Mangifera indica, foi distribuída em todo o mundo para se tornar uma das frutas mais cultivadas nos trópicos. Outras espécies de Mangifera (por exemplo, manga-cavalo, Mangifera foetida) são cultivadas de forma mais localizada.

                Em todo o mundo, existem várias centenas de cultivares de manga. Dependendo da cultivar, a manga varia em tamanho, formato, doçura, cor da casca e cor da polpa, que pode ser amarelo claro, dourado ou laranja. A manga é a fruta nacional da Índia e do Paquistão e a árvore nacional de Bangladesh. É a fruta nacional não oficial das Filipinas.

                DESCRIÇÃO

                As mangueiras crescem até 35–40 m (115–131 pés) de altura, com um raio de copa de 10 m (33 pés). As árvores têm vida longa, pois alguns exemplares ainda frutificam após 300 anos.[9] Em solo profundo, a raiz principal desce a uma profundidade de 6 m (20 pés), com raízes alimentadoras abundantes e amplamente espalhadas e raízes âncora penetrando profundamente no solo. As folhas são perenes, alternadas, simples, com 15–35 cm (5,9–13,8 pol.) de comprimento e 6–16 cm (2,4–6,3 pol.) de largura; quando as folhas são jovens, elas são rosa-alaranjadas, mudando rapidamente para um vermelho escuro e brilhante e depois para um verde escuro à medida que amadurecem. As flores são produzidas em panículas terminais de 10–40 cm (3,9–15,7 pol.) de comprimento; cada flor é pequena e branca com cinco pétalas de 5–10 mm (0,20–0,39 pol.) de comprimento, com uma fragrância suave e doce. São conhecidas mais de 500 variedades de manga,[1] muitas das quais amadurecem no verão, enquanto algumas dão uma colheita dupla. O fruto leva de quatro a cinco meses desde a floração até amadurecer.

                CULTIVO

                As mangas são cultivadas no Sul da Ásia há milhares de anos e chegaram ao Sudeste Asiático entre os séculos V e IV aC. Por volta do século 10 dC, o cultivo começou na África Oriental.[12] O viajante marroquino do século XIV, Ibn Battuta, relatou isso em Mogadíscio. O cultivo chegou posteriormente ao Brasil, Bermudas, Índias Ocidentais e México, onde um clima adequado permite o seu crescimento.

        A manga é agora cultivada na maioria dos climas tropicais e subtropicais mais quentes, sem geadas; quase metade das mangas do mundo são cultivadas apenas na Índia, sendo a segunda maior fonte a China. A manga também é cultivada na Andaluzia, Espanha (principalmente na província de Málaga), visto que o seu clima subtropical costeiro é um dos poucos locais na Europa continental que permite o crescimento de plantas tropicais e árvores frutíferas. As Ilhas Canárias são outro notável produtor espanhol da fruta. Outros cultivadores incluem a América do Norte (no sul da Flórida e no Vale Coachella da Califórnia), América do Sul e Central, Caribe, Havaí, sul, oeste e África central, Austrália, China, Coreia do Sul, Paquistão, Bangladesh e Sudeste Asiático. Embora a Índia seja o maior produtor de manga, representa menos de 1% do comércio internacional de manga; A Índia consome a maior parte da sua própria produção.

                CULINÁRIA

                Existem muitas centenas de cultivares de manga nomeadas. Nos pomares de manga, vários cultivares são frequentemente cultivados para melhorar a polinização. Muitas cultivares desejadas são monoembrionárias e devem ser propagadas por enxerto ou não se reproduzem verdadeiramente. Uma cultivar monoembrionária comum é o 'Alphonso', importante produto de exportação, considerado “o rei das mangas”.

                Cultivares que se destacam em um clima podem falhar em outro. Por exemplo, cultivares indianas como 'Julie', uma cultivar prolífica na Jamaica, requerem tratamentos anuais com fungicidas para escapar da doença fúngica letal antracnose na Flórida. As mangas asiáticas são resistentes à antracnose.

                O mercado mundial atual é dominado pela cultivar 'Tommy Atkins', uma muda de 'Haden' que frutificou pela primeira vez em 1940 no sul da Flórida e foi inicialmente rejeitada comercialmente pelos pesquisadores da Flórida.[22] Produtores e importadores em todo o mundo adotaram a cultivar por sua excelente produtividade e resistência a doenças, prazo de validade, transportabilidade, tamanho e cor atraente.[23] Embora a cultivar Tommy Atkins seja comercialmente bem-sucedida, outras cultivares podem ser preferidas pelos consumidores para o prazer alimentar, como a Alphonso.
        
        Geralmente, as mangas maduras têm casca amarelo-alaranjada ou avermelhada e são suculentas para comer, enquanto as frutas exportadas costumam ser colhidas ainda pouco maduras e com casca verde. Embora produzam etileno durante o amadurecimento, as mangas exportadas não amadurecidas não têm a mesma suculência ou sabor que as frutas frescas.
        """,
      nutrition: ["250 kJ (60 kcal)","13,7 g","0,38 g","0,82 g","A, B1, B2, B3, B5, B6, B9, C, E, K","Cálcio, Ferro, Magnásio, Manganês, Fósforo, Potássio, Sódio, Zinco"]
    ),
    Fruit(
      title: "Melancia",
      headline: "frutas doces em forma de sino, apreciadas desde a antiguidade. Eles podem ser consumidos crocantes ou macios.",
      image: "melancia",
      gradientColors: [Color("ColorWatermelonLight"), Color("ColorWatermelonDark")],
      description: """
        A melancia (Citrullus lanatus) é uma espécie de planta da família Cucurbitaceae, uma planta com flor semelhante a uma videira originalmente domesticada na África Ocidental. É uma fruta muito cultivada em todo o mundo, possuindo mais de 1000 variedades.

                A melancia é uma trepadeira trepadeira da família das plantas com flores Cucurbitaceae. Há evidências de sementes nas tumbas do Faraó do cultivo de melancia no Antigo Egito. A melancia é cultivada em climas favoráveis, de regiões tropicais a temperadas em todo o mundo, por seu grande fruto comestível, que é uma baga com casca dura e sem divisões internas, e é botanicamente chamada de pepo.

                A polpa doce e suculenta é geralmente de um vermelho profundo a rosa, com muitas sementes pretas, embora existam variedades sem sementes. A fruta pode ser consumida crua ou em conserva, e a casca fica comestível após o cozimento. É comumente consumido como suco ou como ingrediente de bebidas mistas.

                DESCRIÇÃO

                A melancia é uma planta anual que tem hábito prostrado ou trepador. Os caules têm até 3 metros (10 pés) de comprimento e o crescimento novo tem pêlos amarelos ou marrons. As folhas têm 60 a 200 milímetros (2 1⁄4 a 7 3⁄4 polegadas) de comprimento e 40 a 150 mm (1 1⁄2 a 6 pol.) de largura. Geralmente têm três lóbulos que são lobados ou duplamente lobados. As plantas têm flores masculinas e femininas em caules peludos de 40 milímetros de comprimento (1 1/2 pol.). São amarelos e esverdeados no dorso.

                A melancia é uma grande planta anual com caules longos, fracos, rastejantes ou trepadeiras, com cinco ângulos (cinco lados) e até 3 m (10 pés) de comprimento. O crescimento jovem é densamente lanoso com cerdas castanho-amareladas que desaparecem à medida que a planta envelhece. As folhas são grandes, grossas, peludas, com lóbulos pinados e alternadas; eles ficam rígidos e ásperos quando velhos. A planta possui gavinhas ramificadas.

        As flores brancas a amarelas crescem isoladamente nas axilas das folhas e a corola é branca ou amarela por dentro e amarelo-esverdeada por fora. As flores são unissexuais, com flores masculinas e femininas ocorrendo na mesma planta (monóicas). As flores masculinas predominam no início da estação; as flores femininas, que se desenvolvem posteriormente, apresentam ovários inferiores. Os estilos são unidos em uma única coluna. O fruto grande é uma espécie de baga modificada chamada pepo, com casca grossa (exocarpo) e centro carnudo (mesocarpo e endocarpo).

                As plantas silvestres têm frutos de até 20 cm (8 pol.) De diâmetro, enquanto as variedades cultivadas podem ultrapassar 60 cm (24 pol.). A casca do fruto é verde médio a escuro e geralmente manchada ou listrada, e a polpa, contendo numerosas sementes espalhadas por seu interior, pode ser vermelha ou rosa (mais comumente), laranja, amarela, verde ou branca.

                CULINÁRIA

                As melancias são plantas cultivadas em climas tropicais a temperados, necessitando de temperaturas superiores a cerca de 25 °C (77 °F) para prosperar. Em escala de jardim, as sementes são geralmente semeadas em vasos cobertos e transplantadas para solo arenoso bem drenado, com pH entre 5,5 e 7 e níveis médios de nitrogênio.

                As principais pragas da melancia incluem pulgões, moscas-das-frutas e nematóides das galhas. Em condições de alta umidade, as plantas são propensas a doenças como o oídio e o vírus do mosaico.[22] Algumas variedades frequentemente cultivadas no Japão e em outras partes do Extremo Oriente são suscetíveis à murcha de fusarium. Enxertar essas variedades em porta-enxertos resistentes a doenças oferece proteção.

                O Departamento de Agricultura dos EUA recomenda a utilização de pelo menos uma colmeia por acre (4.000 m2 por colmeia) para a polinização de variedades convencionais com sementes para plantações comerciais. Os híbridos sem sementes possuem pólen estéril. Isto requer o plantio de fileiras polinizadoras de variedades com pólen viável. Dado que o fornecimento de pólen viável é reduzido e a polinização é muito mais crítica na produção da variedade sem sementes, o número recomendado de colmeias por acre (densidade de polinizadores) aumenta para três colmeias por acre (1.300 m2 por colmeia). As melancias têm um período de crescimento mais longo do que outros melões e muitas vezes pode levar 85 dias ou mais a partir do momento do transplante para que a fruta amadureça.

                Acredita-se que a falta de pólen contribua para o "coração oco", que faz com que a polpa da melancia crie um grande buraco, às vezes em uma forma intrincada e simétrica. Melancias com coração vazio são seguras para consumo.
        """,
      nutrition: ["127 kJ (30 kcal)","6,2 g","0,15 g","0,61 g","A, B1, B2, B3, B5, B6, C","Cálcio, Ferro, Magnésio, Manganês, Fósforo, Potássio, Sódio, Zinco"]
    ),
    Fruit(
      title: "Cereja",
      headline: "Srutas doces em forma de sino, apreciadas desde a antiguidade. Eles podem ser consumidos crocantes ou macios.",
      image: "cereja",
      gradientColors: [Color("ColorCherryLight"), Color("ColorCherryDark")],
      description: """
        A cereja é o fruto de muitas plantas do gênero Prunus e é uma drupa carnuda (fruta com caroço). As cerejas comerciais são obtidas a partir de cultivares de diversas espécies, como a doce Prunus avium e a azeda Prunus cerasus.

                O nome 'cereja' também se refere à cerejeira e sua madeira, e às vezes é aplicado a amêndoas e árvores com flores visualmente semelhantes do gênero Prunus, como em "cereja ornamental" ou "flor de cerejeira". Cereja selvagem pode se referir a qualquer uma das espécies de cereja que crescem fora do cultivo, embora Prunus avium seja frequentemente referido especificamente pelo nome de "cereja selvagem" nas Ilhas Britânicas.

                CULINÁRIA

                As formas cultivadas são da espécie cereja doce (P. avium), à qual pertence a maioria das cultivares de cereja, e da cereja azeda (P. cerasus), utilizada principalmente para cozinhar. Ambas as espécies são originárias da Europa e da Ásia Ocidental; eles geralmente não fazem polinização cruzada. Algumas outras espécies, embora tenham frutos comestíveis, não são cultivadas extensivamente para consumo, excepto nas regiões do norte, onde as duas espécies principais não crescem.

                A irrigação, a pulverização, a mão de obra e sua propensão a danos causados ​​pela chuva e pelo granizo tornam as cerejas relativamente caras. Mesmo assim, a procura pela fruta é alta. Na produção comercial, as ginjas, assim como às vezes as cerejas doces, são colhidas usando um "agitador" mecanizado. A colheita manual também é amplamente utilizada para cerejas doces e ácidas para colher os frutos e evitar danos aos frutos e às árvores.

                Os porta-enxertos comuns incluem Mazzard, Mahaleb, Colt e Gisela Series, um porta-enxerto anão que produz árvores significativamente menores do que outras, com apenas 2,5 a 3 metros de altura. As ginjas não requerem polinizador, enquanto poucas variedades doces são autoférteis.

                Uma cerejeira leva de três a quatro anos, depois de plantada no pomar, para produzir sua primeira safra de frutos e sete anos para atingir a maturidade plena.
        """,
      nutrition: ["209 kJ (50 kcal)","8,5 g","0,3 g","1 g","A, B1, B2, B3, B5, B6, B9, C, K","Cálcio, Ferro, Magnésio, Manganês, Fósforo, Potássio, Sódio, Zinco"]
    ),
    Fruit(
      title: "Toranja",
      headline: "frutas doces em forma de sino, apreciadas desde a antiguidade. Eles podem ser comidos crocantes ou macios.",
      image: "toranja",
      gradientColors: [Color("ColorGrapefruitLight"), Color("ColorGrapefruitDark")],
      description: """
        A toranja (Citrus × paradisi) é uma árvore cítrica subtropical conhecida por seus frutos relativamente grandes, azedos a meio amargos e um tanto amargos. A toranja é um híbrido cítrico originário de Barbados como um cruzamento acidental entre a laranja doce (C. sinensis) e o pomelo (ou sombra; C. maxima), ambos introduzidos na Ásia no século XVII. Quando encontrado, foi apelidado de “fruto proibido”. Freqüentemente, é identificado erroneamente como a espécie parental muito semelhante, o pomelo.

                A parte “uva” do nome alude a cachos de frutas na árvore que muitas vezes parecem semelhantes a cachos de uvas. A polpa interna é segmentada e varia em cor do branco ao amarelo, do rosa ao vermelho.

                DESCRIÇÃO

                As toranjas perenes geralmente crescem até cerca de 5–6 m (16–20 pés) de altura, embora possam atingir 13–15 m (43–49 pés). As folhas são brilhantes, verde-escuras, longas (até 15 cm (5,9 pol.)) e finas. Produz flores brancas de quatro pétalas de 5 cm (2 pol.). O fruto tem casca amarelo-laranja e geralmente tem formato esferóide achatado; varia em diâmetro de 10 a 15 cm (3,9 a 5,9 pol.). A polpa é segmentada e ácida, variando em cor dependendo dos cultivares, que incluem polpas brancas, rosadas e vermelhas de doçura variada (geralmente as variedades mais vermelhas são as mais doces). O Ruby Red dos EUA de 1929 (da variedade 'Redblush') tem a primeira patente de toranja.

                CULINÁRIA

                As variedades de toranja são diferenciadas pela cor da polpa dos frutos que produzem. As variedades comuns são as cores de polpa vermelha, branca e rosa. Os sabores variam de altamente ácidos e um tanto azedos a doces e azedos, resultantes da composição de açúcares (principalmente sacarose), ácidos orgânicos (principalmente ácido cítrico) e monoterpenos e sesquiterpenos que proporcionam aromas.

                O mercaptano de toranja, um terpeno contendo enxofre, é um dos compostos aromáticos que influenciam o sabor e o odor da toranja, em comparação com outras frutas cítricas.

        A toranja crua contém 90% de água, 8% de carboidratos, 1% de proteína e gordura insignificante (tabela). Na quantidade de referência de 100 g, a toranja crua fornece 33 calorias e é uma rica fonte de vitamina C (40% do valor diário), sem outros micronutrientes em teor significativo.

                Na Costa Rica, especialmente em Atenas, as toranjas são frequentemente cozidas para remover a acidez, tornando-as doces; também são recheados com doce de leite, resultando em uma sobremesa chamada toronja rellena (toranja recheada). No Haiti, a toranja é usada principalmente para fazer suco (jus de Chadèque), mas também para fazer geléia (confiture de Chadèque).
        """,
      nutrition: ["138 kJ (33 kcal)","7,31 g","0,10 g","0,8 g","B1, B2, B3, B5, B6, B9, C, E","Cálcio, Ferro, Magnésio, Manganês, Fósforo, Potássio, Zinco"]
    ),
    Fruit(
      title: "Maçã",
      headline: "As maçãs são uma das frutas mais populares e excepcionalmente saudáveis ​​por um bom motivo.",
      image: "maçã",
      gradientColors: [Color("ColorAppleLight"), Color("ColorAppleDark")],
      description: """
        A maçã é uma fruta comestível produzida por uma macieira (Malus domestica). As macieiras são cultivadas em todo o mundo e são as espécies mais cultivadas do gênero Malus. A árvore é originária da Ásia Central, onde seu ancestral selvagem, Malus sieversii, ainda hoje é encontrado. As maçãs são cultivadas há milhares de anos na Ásia e na Europa e foram trazidas para a América do Norte pelos colonos europeus. As maçãs têm significado religioso e mitológico em muitas culturas, incluindo a tradição nórdica, grega e cristã europeia.

                DESCRIÇÃO

                A maçã é uma árvore caducifólia, geralmente medindo 2 a 4,5 m (6 a 15 pés) de altura no cultivo e até 9 m (30 pés) na natureza. Quando cultivado, o tamanho, a forma e a densidade dos ramos são determinados pela seleção do porta-enxerto e pelo método de poda. As folhas são ovais simples, dispostas alternadamente, de cor verde escuro, com margens serrilhadas e parte inferior ligeiramente felpuda.

                As flores são produzidas na primavera simultaneamente com a brotação das folhas e são produzidas em esporas e alguns brotos longos. As flores de 3 a 4 cm (1 a 1 1/2 pol.) São brancas com um tom rosa que desaparece gradualmente, cinco pétalas, com uma inflorescência composta por um cimo com 4–6 flores. A flor central da inflorescência é chamada de “flor rei”; ele abre primeiro e pode desenvolver um fruto maior.

                CULTIVO

                Existem mais de 7.500 cultivares conhecidas de maçãs.[44] As cultivares variam em seu rendimento e no tamanho final da árvore, mesmo quando cultivadas no mesmo porta-enxerto.[45] Diferentes cultivares estão disponíveis para climas temperados e subtropicais. A Coleção Nacional de Frutas do Reino Unido, que é de responsabilidade do Departamento de Meio Ambiente, Alimentação e Assuntos Rurais, inclui uma coleção de mais de 2.000 cultivares de macieira em Kent.

                O banco de dados nacional de coleta de frutas do Reino Unido contém muitas informações sobre as características e a origem de muitas maçãs, incluindo nomes alternativos para o que é essencialmente o mesmo cultivar “genético” de maçã. A maioria dessas cultivares é cultivada para consumo fresco (maçãs para sobremesa), embora algumas sejam cultivadas especificamente para cozinhar (cozinhar maçãs) ou produzir cidra. Maçãs para cidra são normalmente muito ácidas e adstringentes para serem consumidas frescas, mas dão à bebida um sabor rico que as maçãs para sobremesa não conseguem.

        Os cultivares de maçã comercialmente populares são macios, mas crocantes. Outras qualidades desejáveis ​​no melhoramento comercial moderno de maçãs são casca colorida, ausência de carepa, facilidade de transporte, capacidade de armazenamento prolongado, alto rendimento, resistência a doenças, formato comum de maçã e sabor desenvolvido. As maçãs modernas são geralmente mais doces do que as cultivares mais antigas, já que os gostos populares das maçãs variaram ao longo do tempo. A maioria dos norte-americanos e europeus prefere maçãs doces e subácidas, mas as maçãs azedas têm uma forte minoria de seguidores. Maçãs extremamente doces com quase nenhum sabor ácido são populares na Ásia, especialmente no subcontinente indiano.
        """,
      nutrition: ["218 kJ (52 kcal)","10,39 g","0,17 g","0,26 g","A, B1, B2, B3, B5, B6, B9, C, E, K","Cálcio, Ferro, Magnásio, Manganês, Fósforo, Potássio, Sódio, Zinco"]
    )
]
