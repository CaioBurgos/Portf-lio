//
//  Teste.swift
//  Fructus
//
//  Created by Caio Burgos dos Santos on 05/10/23.
//

import SwiftUI

struct SettingsView: View {
  // MARK: - PROPERTIES
  
  @Environment(\.presentationMode) var presentationMode
  @AppStorage("isOnboarding") var isOnboarding: Bool = false
  
  // MARK: - BODY

  var body: some View {
    NavigationView {
      ScrollView(.vertical, showsIndicators: false) {
        VStack(spacing: 20) {
          // MARK: - SECTION 1
          
          GroupBox(
            label:
              SettingsLabelView(labelText: "Frutas", labelImage: "info.circle")
          ) {
            Divider().padding(.vertical, 4)
            
            HStack(alignment: .center, spacing: 10) {
              Image("logo")
                .resizable()
                .scaledToFit()
                .frame(width: 80, height: 80)
                .cornerRadius(9)
              
              Text("A maioria das frutas é naturalmente pobre em gordura, sódio e calorias. Nenhum tem colesterol. As frutas são fontes de muitos nutrientes essenciais, incluindo potássio, fibra alimentar, vitaminas e muito mais.")
                .font(.footnote)
            }
          }
          
          // MARK: - SECTION 2
          
          GroupBox(
            label: SettingsLabelView(labelText: "Customização", labelImage: "paintbrush")
          ) {
            Divider().padding(.vertical, 4)
            
            Text("Se desejar, você pode reiniciar o aplicativo alternando a opção nesta caixa. Dessa forma, inicia-se o processo de integração e você verá novamente a tela de boas-vindas.")
              .padding(.vertical, 8)
              .frame(minHeight: 60)
              .layoutPriority(1)
              .font(.footnote)
              .multilineTextAlignment(.leading)
            
            Toggle(isOn: $isOnboarding) {
              if isOnboarding {
                Text("Reiniciado".uppercased())
                  .fontWeight(.bold)
                  .foregroundColor(Color.green)
              } else {
                Text("Reiniciar".uppercased())
                  .fontWeight(.bold)
                  .foregroundColor(Color.secondary)
              }
            }
            .padding()
            .background(
              Color(UIColor.tertiarySystemBackground)
                .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
            )
          }
          
          // MARK: - SECTION 3
          
          GroupBox(
            label:
            SettingsLabelView(labelText: "Aplicação", labelImage: "apps.iphone")
          ) {
            SettingsRowView(name: "Developer", content: "Caio Burgos")
            SettingsRowView(name: "Compatibility", content: "iOS 16")
            SettingsRowView(name: "GitHub", linkLabel: "CaioBurgos", linkDestination: "github.com/CaioBurgos")
            SettingsRowView(name: "SwiftUI", content: "4")
            SettingsRowView(name: "Version", content: "1.5.0")
          }
          
        } //: VSTACK
        .navigationBarTitle(Text("Settings"), displayMode: .large)
        .navigationBarItems(
          trailing:
            Button(action: {
              presentationMode.wrappedValue.dismiss()
            }) {
              Image(systemName: "xmark")
            }
        )
        .padding()
      } //: SCROLL
    } //: NAVIGATION
  }
}

// MARK: - PREVIEW

struct SettingsView_Previews: PreviewProvider {
  static var previews: some View {
    SettingsView()
      .preferredColorScheme(.dark)
      .previewDevice("iPhone 13")
  }
}
